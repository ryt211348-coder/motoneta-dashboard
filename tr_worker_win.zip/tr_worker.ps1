﻿# 文字起こしワーカー(Windows用)
# ダッシュボードの「解析」で依頼された動画の字幕をこのPCが取得してGASへ納品する。
# 起動.bat から実行。初回は yt-dlp.exe (公式) を自動ダウンロードする。
$API = "https://script.google.com/macros/s/AKfycbzRbrv9of3ZFrN0I4UYd0Ufi8O0PORkTPJwWqrJ4a44bPiodWNq64iiiaMOD3I1D-_O/exec"
$ErrorActionPreference = "Continue"
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
# Windows PowerShell 5.1はTLS1.2を明示しないとGitHub等への接続に失敗する
try { [Net.ServicePointManager]::SecurityProtocol = [Net.ServicePointManager]::SecurityProtocol -bor 3072 } catch {}

$dir = Split-Path -Parent $MyInvocation.MyCommand.Path
$ytdlp = Join-Path $dir "yt-dlp.exe"
if (!(Test-Path $ytdlp)) {
  if ($IsMacOS -and (Test-Path "/opt/homebrew/bin/yt-dlp")) {
    $ytdlp = "/opt/homebrew/bin/yt-dlp"  # Mac検証用
  } else {
    Write-Host "初回セットアップ: yt-dlp.exe (公式) をダウンロードしています..."
    Invoke-WebRequest -UseBasicParsing -Uri "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe" -OutFile $ytdlp
    Write-Host "ダウンロード完了"
  }
}

function Get-Transcript($vid) {
  $raw = & $ytdlp --no-update -J --skip-download ("https://www.youtube.com/watch?v=" + $vid) 2>$null
  if (-not $raw) { return $null }
  $info = $raw | ConvertFrom-Json
  $lang = "" + $info.language
  $tracks = $null
  foreach ($d in @($info.subtitles, $info.automatic_captions)) {
    if (-not $d) { continue }
    $names = @($d.PSObject.Properties.Name)
    if (-not $names.Count) { continue }
    # 原語優先: 手動字幕 > 自動字幕(<lang>-origが原語)
    foreach ($k in (@($lang, ($lang + "-orig"), "en-orig", "en") + $names)) {
      if ($k -and ($names -contains $k)) { $tracks = $d.$k; break }
    }
    if ($tracks) { break }
  }
  if (-not $tracks) { return $null }
  $t = $tracks | Where-Object { $_.ext -eq "json3" } | Select-Object -First 1
  if (-not $t) { $t = @($tracks)[0] }
  $url = "" + $t.url
  if ($url -notmatch "fmt=json3") { $url += "&fmt=json3" }
  $data = Invoke-RestMethod -Uri $url -Headers @{ "User-Agent" = "Mozilla/5.0" } -TimeoutSec 60
  $lines = New-Object System.Collections.Generic.List[string]
  foreach ($e in $data.events) {
    if (-not $e.segs) { continue }
    $txt = ((@($e.segs) | ForEach-Object { "" + $_.utf8 }) -join "").Replace("`n", " ").Trim()
    if (-not $txt) { continue }
    $ms = 0; if ($e.tStartMs) { $ms = [int64]$e.tStartMs }
    $sec = [int][math]::Floor($ms / 1000)
    $lines.Add(("[{0}:{1:d2}] {2}" -f [int][math]::Floor($sec / 60), ($sec % 60), $txt))
  }
  if ($lines.Count) { return ($lines -join "`n") } else { return $null }
}

Write-Host "=========================================="
Write-Host " 文字起こしワーカー起動中"
Write-Host " このウィンドウを開いている間、チーム全員の"
Write-Host " 文字起こしをこのPCが自動取得します。"
Write-Host " 終了するときはウィンドウを閉じるだけでOK。"
Write-Host "=========================================="
while ($true) {
  $q = @()
  try { $q = @((Invoke-RestMethod -Uri ($API + "?api=trpoll") -TimeoutSec 60).q) } catch { Start-Sleep 30 }
  foreach ($vid in $q) {
    if (-not $vid) { continue }
    # ig_◯◯はInstagram素材。文字起こし(Whisper)ができるりゅうとMacだけが担当する
    if ("$vid" -like "ig_*") { continue }
    Write-Host ((Get-Date -Format "HH:mm:ss") + " 取得中: " + $vid)
    $body = $null
    try {
      $text = Get-Transcript $vid
      if ($text) { $body = @{ vid = $vid; text = $text } }
      else { $body = @{ vid = $vid; err = "この動画には字幕がありません" } }
    } catch {
      $msg = "" + $_
      $body = @{ vid = $vid; err = $msg.Substring(0, [math]::Min(200, $msg.Length)) }
    }
    try {
      $json = ConvertTo-Json $body -Compress
      Invoke-RestMethod -Uri ($API + "?api=trpush") -Method Post -ContentType "text/plain; charset=utf-8" `
        -Body ([System.Text.Encoding]::UTF8.GetBytes($json)) -TimeoutSec 90 | Out-Null
      if ($body.text) { Write-Host ("  → 納品OK (" + $body.text.Length + "文字)") }
      else { Write-Host ("  → 字幕なしとして報告: " + $body.err) }
    } catch { Write-Host ("  → 送信失敗: " + $_) }
  }
  Start-Sleep 10
}
