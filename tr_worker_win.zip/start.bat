@echo off
cd /d "%~dp0"
title tr-worker
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0tr_worker.ps1"
pause
